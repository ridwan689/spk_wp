<!-- Love SweetAlert? Please consider supporting our collective:
👉  https://opencollective.com/SweetAlert/donate -->